#!/bin/bash

echo "Hello! this is a docker image built from remote docker java client"
